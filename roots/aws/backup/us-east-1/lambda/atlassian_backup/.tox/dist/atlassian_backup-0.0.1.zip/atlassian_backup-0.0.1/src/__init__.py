import os
import re
import time

import boto3
import botocore
import requests
from smart_open import open

REGION = "us-east-1"


def main():
    lambda_handler()


def elastio_mock(conf_url, jira_url, bucket):

    print("Mocking a vault redirect")
    headers = {"Content-Type": "application/json"}

    print(f"Working on {conf_url}")

    c = requests.Session()
    c_file = c.get(conf_url, stream=True)

    try:
        c_file.raise_for_status()
    except requests.exceptions.HTTPError as e:
        print("Something went wrong")
        return {"statusCode": 403, "headers": headers, "body": e}

    c_url = f"s3://{bucket}/confluence_vault"
    with open(c_url, "wb") as h:
        for block in c_file.iter_content(1024):
            h.write(block)

    print(f"Working on {jira_url}")
    j = requests.Session()
    j_file = j.get(jira_url, stream=True)

    try:
        j_file.raise_for_status()
    except requests.exceptions.HTTPError as e:
        print("Something went wrong")
        return {"statusCode": 403, "headers": headers, "body": e}

    j_url = f"s3://{bucket}/jira_vault"
    with open(j_url, "wb") as ha:
        for block in j_file.iter_content(1024):
            ha.write(block)

    return {"statusCode": 200, "headers": headers, "body": "OK"}


def get_secrets(client):

    site = client.get_parameter(Name="/atlassian/site", WithDecryption=True)[
        "Parameter"
    ]["Value"]
    user = client.get_parameter(Name="/atlassian/user", WithDecryption=True)[
        "Parameter"
    ]["Value"]
    token = client.get_parameter(Name="/atlassian/api_token", WithDecryption=True)[
        "Parameter"
    ]["Value"]
    return site, user, token


def whoami(client):
    client.get_caller_identity()


def backup_confluence(site, user, token):
    # global variables
    global backup_response
    global file_name

    json = b'{"cbAttachments": "true", "exportToCloud": "true"}'
    url = "https://" + site + ".atlassian.net/wiki"

    session = requests.Session()
    session.auth = (user, token)
    session.headers.update(
        {"Accept": "application/json", "Content-Type": "application/json"}
    )

    backup_start = session.post(url + "/rest/obm/1.0/runbackup", data=json)

    # Catch error response from backup start and exit if error found.
    try:
        backup_response = int(
            re.search("(?<=<Response \[)(.*?)(?=\])", str(backup_start)).group(1)
        )
    except AttributeError:
        print(backup_start.text)
        exit(1)

    # Check backup startup response is 200 if not print error and exit.
    if backup_response != 200:
        print(backup_start.text)
        exit(1)
    else:
        print("Backup starting...")

    progress_req = session.get(url + "/rest/obm/1.0/getprogress")

    # Check for filename match in response
    file_name = str(re.search('(?<=fileName":")(.*?)(?=")', progress_req.text))

    # If no file name match in JSON response keep outputting progress every 10 seconds
    while file_name == "None":

        progress_req = session.get(url + "/rest/obm/1.0/getprogress")
        # Regex to extract elements of JSON progress response.
        file_name = str(re.search('(?<=fileName":")(.*?)(?=")', progress_req.text))
        estimated_percentage = str(
            re.search('(?<=Estimated progress: )(.*?)(?=")', progress_req.text)
        )
        error = "error"
        # While there is an estimated percentage this will be output.
        if estimated_percentage != "None":
            # Regex for current status.
            current_status = str(
                re.search('(?<=currentStatus":")(.*?)(?=")', progress_req.text).group(1)
            )
            # Regex for percentage progress value
            estimated_percentage_value = str(
                re.search(
                    '(?<=Estimated progress: )(.*?)(?=")', progress_req.text
                ).group(1)
            )
            print(
                f"Action: {current_status} / Overall progress: {estimated_percentage_value}"
            )
            time.sleep(10)
        # Once no estimated percentage in response the alternative progress is output.
        elif estimated_percentage == "None":
            # Regex for current status.
            current_status = str(
                re.search('(?<=currentStatus":")(.*?)(?=")', progress_req.text).group(1)
            )
            # Regex for alternative percentage value.
            alt_percentage_value = str(
                re.search(
                    '(?<=alternativePercentage":")(.*?)(?=")', progress_req.text
                ).group(1)
            )
            print(
                f"Action: {current_status} / Overall progress: {alt_percentage_value}"
            )
            time.sleep(10)
        # Catch any instance of the of word 'error' in the response and exit script.
        elif error.casefold() in progress_req.text:
            print(progress_req.text)
            exit(1)

    # Get filename from progress JSON
    file_name = str(re.search('(?<=fileName":")(.*?)(?=")', progress_req.text))

    # Check filename is not None
    if file_name != "None":
        file_name = str(
            re.search('(?<=fileName":")(.*?)(?=")', progress_req.text).group(1)
        )

        site = f"{url}/wiki/download/{file_name}"
        print(f"Backup file can be downloaded from {site}")

        return site


def backup_jira(site, user, token):
    url = "https://" + site + ".atlassian.net"
    json = b'{"cbAttachments": "true", "exportToCloud": "true"}'

    # Open new session for cookie persistence and auth.
    session = requests.Session()
    session.auth = (user, token)
    session.headers.update(
        {"Accept": "application/json", "Content-Type": "application/json"}
    )

    # Start backup
    backup_req = session.post(url + "/rest/backup/1/export/runbackup", data=json)

    # Catch error response from backup start and exit if error found.
    if "error" in backup_req.text:
        print(backup_req.text)
        exit(1)

    # Get task ID of backup.
    task_req = session.get(url + "/rest/backup/1/export/lastTaskId")
    task_id = task_req.text

    # set starting task progress values outside of while loop and if statements.
    task_progress = 0
    last_progress = -1
    global progress_req

    # Get progress and print update until complete
    while task_progress < 100:

        progress_req = session.get(
            url + "/rest/backup/1/export/getProgress?taskId=" + task_id
        )

        # Chop just progress update from json response
        try:
            task_progress = int(
                re.search('(?<=progress":)(.*?)(?=,)', progress_req.text).group(1)
            )
            # print(progress_req.text)
        except AttributeError:
            print(progress_req.text)
            exit(1)

        if (last_progress != task_progress) and "error" not in progress_req.text:
            print(task_progress)
            last_progress = task_progress
        elif "error" in progress_req.text:
            print(progress_req.text)
            exit(1)

        if task_progress < 100:
            time.sleep(10)

    if task_progress == 100:

        download = re.search('(?<=result":")(.*?)(?=",)', progress_req.text).group(1)

        site = f"{url}/plugins/servlet/{download}"
        print(f"Backup file can be downloaded from {site}")

        return site


def backup(site, user, token):
    conf_url = backup_confluence(site, user, token)
    jira_url = backup_jira(site, user, token)

    return conf_url, jira_url


def send_sns(client, message):
    try:
        sns_topic_arn = os.environ["SNS_TOPIC_ARN"]
    except:
        return False
    client.publish(
        TopicArn=sns_topic_arn,
        Message=message,
        Subject="Atlassian Has Been Successfully Backed Up",
    )
    return True


def lambda_handler():

    S3_BUCKET = "iot4-backup-biggfiles"

    headers = {"Content-Type": "application/json"}

    dry_run = os.getenv("DRY_RUN")

    try:
        whoami(boto3.client("sts", region_name=REGION))
    except botocore.exceptions.NoCredentialsError as e:
        return {"statusCode": 403, "headers": headers, "body": e}
    except botocore.exceptions.ClientError as e:
        return {"statusCode": 403, "headers": headers, "body": e}

    try:
        site, user, token = get_secrets(boto3.client("ssm", region_name=REGION))
    except botocore.exceptions.ClientError as e:
        return {"statusCode": 404, "headers": headers, "body": e}

    if dry_run == "True":
        message = "Mission Control: All Systems are Go. "
        return {"statusCode": 204, "headers": headers, "body": message}

    else:

        print("Starting Atlassian Backup, press CTRL+C to cancel.")
        time.sleep(10)

        try:
            # conf_url, jira_url = backup(site, user, token)
            print("Skipping for 24 hours. Downloading old files")
            conf_url = "https://theonlyiot4.atlassian.net/wiki/download/temp/filestore/d430189a-cc00-4c99-adfd-82f53e7120d9"
            jira_url = "https://theonlyiot4.atlassian.net/plugins/servlet/export/download/?fileId=739f9c9e-1b56-46e8-aaf1-1b459105c067"
        except:
            e = "An unexpected error occured. Please check the logs and try again."
            return {"statusCode": 503, "headers": headers, "body": e}

        # Backup was successful
        # Mock up an elastio vault write

        elastio_mock(conf_url, jira_url, S3_BUCKET)

        message = f"Recovery URLs attached.\n {conf_url} \n {jira_url}\n"
        send_sns(boto3.client("sts", region_name=REGION), message)

        return {"statusCode": 200, "headers": headers, "body": message}

    message = "Please Check the Account and Try Again."
    return {"statusCode": 404, "headers": headers, "body": message}


if __name__ == "__main":
    main()
