import boto3
import pytest
from moto import mock_ec2, mock_organizations, mock_sts

import aws_tools


@mock_organizations
def create_organization():
    client = boto3.client("organizations")
    response = client.create_organization(FeatureSet="ALL")
    assert response["Organization"]["FeatureSet"] == "ALL"


@mock_organizations
def create_accounts():
    response = client.create_account(Email="test", AccountName="test")


@pytest.fixture(scope="function")
def sts():
    with mock_sts():
        yield boto3.client("sts")


@pytest.fixture(scope="function")
def ec2():
    with mock_ec2():
        yield boto3.client("ec2")


@mock_sts
@mock_organizations
def test_get_accounts_list():

    create_organization()

    accounts = get_accounts_list(boto3.client("organizations", region_name="us-east-1"))

    assert len(accounts) == 3
