tar czf ../../../apps/secubernetes/ansible/files/workers.tar.gz .
